#ifndef __SYS_H
#define __SYS_H		


#define	u8 unsigned char
#define	u16 unsigned int
#define	u32 unsigned long


void delayms(int count);


	  		 
#endif  
	 
	 




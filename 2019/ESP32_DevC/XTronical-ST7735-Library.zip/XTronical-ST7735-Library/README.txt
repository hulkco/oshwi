This is a library for generic 1.44" 128x28 pixel TFT 7735 based displays

Based on Adafruit ST7735 library code for their breakout board

Also requires the Adafruit_GFX library for Arduino.
